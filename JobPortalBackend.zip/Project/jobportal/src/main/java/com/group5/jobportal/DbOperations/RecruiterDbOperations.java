package com.group5.jobportal.DbOperations;

import com.group5.jobportal.Bean.JobSeekerBean;
import com.group5.jobportal.Bean.RecruiterBean;
import com.group5.jobportal.Connection.DbConnection;
import com.mongodb.client.*;
import com.mongodb.client.result.InsertOneResult;
import org.bson.Document;

public class RecruiterDbOperations {
    DbConnection dbconn = null;
    MongoClient mongoClient = null;
    MongoDatabase database = null;

    public String recruiter(RecruiterBean RBean, String op) {
        dbconn = new DbConnection();
        String connectionString = "mongodb://localhost:27017";
        mongoClient = MongoClients.create(connectionString);
        database = dbconn.getdbConnection(mongoClient);
        String status = "";

        if (op.equalsIgnoreCase("register")) {
            Document document = new Document("Fname", RBean.getFirstName()).append("Lname", RBean.getLastName()).append("Email", RBean.getEmail())
                    .append("company", RBean.getCompany()).append("password", RBean.getPassword());
            //System.out.println(database.getCollection("JobSeeker").insertOne(document));
            MongoCollection<Document> collection = database.getCollection("JobSeeker");
            InsertOneResult result = collection.insertOne(document);
            if (!result.getInsertedId().isNull())
                status = "success";
            else
                status = "fail";
            System.out.println("Inserted ID: " + result.getInsertedId());
        } else if (op.equalsIgnoreCase("login")) {
            Document document1 = new Document("Uname", RBean.getEmail()).append("password", RBean.getPassword());//.append("type", "Movie");
            FindIterable<Document> documents = database.getCollection("JobSeeker").find(document1);
            //FindIterable<Document> documents = collection.find(query);

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext())
                status = "success";
            else
                status = "fail";
            /*while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }*/
        }
        mongoClient.close();
        return status;
    }

    public Document posts(RecruiterBean RBean, String op) {
        dbconn = new DbConnection();
        //MongoClient mongoClient = null;
        Document document = null;
        System.out.println("op");
        String connectionString = "mongodb://localhost:27017";
        mongoClient = MongoClients.create(connectionString);
        database = dbconn.getdbConnection(mongoClient);
        System.out.println(database);
        if (op.equalsIgnoreCase("CreatedPosts")) {

            Document document1 = new Document("Recruiter_Id", RBean.getRID());
            //Document regexFilter = new Document("SearchResult", new Document("$regex", JSBean.getKeyword()));
            FindIterable<Document> documents = database.getCollection("JobPosts").find(document1);
            //FindIterable<Document> documents = collection.find(query);

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext()) {
                while (cursor.hasNext()) {
                    document = cursor.next();
                    System.out.println(document.toJson());
                }
            } else
                document = new Document();
            /*while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }*/
        }
        mongoClient.close();
        return document;
    }
}
