package com.group5.jobportal.ServImpl;

import com.group5.jobportal.Bean.EmployerBean;
import com.group5.jobportal.DbOperations.EmployerDbOperations;
import com.group5.jobportal.service.EmployerService;

public class EmployerServImpl implements EmployerService {
    EmployerBean EBean=new EmployerBean();
    //DbConnection dbconn=new DbConnection();
    EmployerDbOperations eregi=new EmployerDbOperations();
    @Override
    public String Eregister(String  email, String password,  String company)
    {
        String op="register";
        EBean.setPassword(password);
        EBean.setEmail(email);
        EBean.setCompany(company);
        String result=eregi.employer(EBean, op);
        return result;
    }


    @Override
    public String Elogin(String email, String password)
    {
        String op="login";
        EBean.setEmail(email);
        EBean.setPassword(password);
        String result=eregi.employer(EBean,op);
        return result;
    }

    @Override
    public String EmpReq(String title, String description,String skills,String exp,String positions,String recruiterid,String pkg)
    {
        String op="empReq";
        EBean.setDescription(description);
        EBean.setSkills(skills);
        EBean.setExp(exp);
        EBean.setPositions(positions);
        EBean.setRecruiterid(recruiterid);
        EBean.setPkg(pkg);
        EBean.setTitle(title);
        String result=eregi.employer(EBean,op);
        return result;
    }

    @Override
    public String editPost(String positions, String Pstatus)
    {
        String op="editpost";
        EBean.setPostStatus(Pstatus);
        EBean.setPositions(positions);
        String result=eregi.employer(EBean,op);
        return result;
    }
}
