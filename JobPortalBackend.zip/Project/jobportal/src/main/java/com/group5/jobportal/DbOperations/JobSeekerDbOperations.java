package com.group5.jobportal.DbOperations;

import com.group5.jobportal.Bean.JobSeekerBean;
import com.group5.jobportal.Connection.DbConnection;
import com.mongodb.client.*;
import com.mongodb.client.result.InsertOneResult;
import org.bson.Document;

public class JobSeekerDbOperations {
    DbConnection dbconn = null;
    MongoClient mongoClient = null;
    MongoDatabase database = null;

    public String jobseeker(JobSeekerBean JSBean, String op) {
        dbconn = new DbConnection();
        String connectionString = "mongodb://localhost:27017";
        mongoClient = MongoClients.create(connectionString);
        database = dbconn.getdbConnection(mongoClient);
        String status = "";

        if (op.equalsIgnoreCase("register")) {
            Document document = new Document("Fname", JSBean.getFirstName()).append("Lname", JSBean.getLastName()).append("Email", JSBean.getEmail())
                    .append("Uname", JSBean.getUsername()).append("password", JSBean.getPassword());
            //System.out.println(database.getCollection("JobSeeker").insertOne(document));
            MongoCollection<Document> collection = database.getCollection("JobSeeker");
            InsertOneResult result = collection.insertOne(document);
            if (!result.getInsertedId().isNull())
                status = "success";
            else
                status = "fail";
            System.out.println("Inserted ID: " + result.getInsertedId());
        } else if (op.equalsIgnoreCase("login")) {
            Document document1 = new Document("Uname", JSBean.getUsername()).append("password", JSBean.getPassword());//.append("type", "Movie");
            System.out.println(document1);
            FindIterable<Document> documents = database.getCollection("JobSeeker").find(document1);
            System.out.println(documents);
            //FindIterable<Document> documents = collection.find(query);

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext())
                status = "success";
            else
                status = "fail";
            /*while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }*/
        }
        mongoClient.close();
        return status;
    }

    public Document jobs(JobSeekerBean JSBean, String op) {
        dbconn = new DbConnection();
        //MongoClient mongoClient = null;
        Document document = null;
        String connectionString = "mongodb://localhost:27017";
        mongoClient = MongoClients.create(connectionString);
        database = dbconn.getdbConnection(mongoClient);
        if (op.equalsIgnoreCase("search")) {
            //Document document1 = new Document("keyword", JSBean.getKeyword());
            Document regexFilter = new Document("SearchResult", new Document("$regex", JSBean.getKeyword()));
            System.out.println(JSBean.getKeyword());
            FindIterable<Document> documents = database.getCollection("JobPosts").find(regexFilter);
            //FindIterable<Document> documents = collection.find(query);

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext()) {
                while (cursor.hasNext()) {
                    document = cursor.next();
                    System.out.println(document.toJson());
                }
            } else
                document = new Document();
            /*while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }*/
        }

        if (op.equalsIgnoreCase("AppliedJobs")) {
            Document document1 = new Document("JId", JSBean.getJid());
            //Document regexFilter = new Document("SearchResult", new Document("$regex", JSBean.getKeyword()));
            FindIterable<Document> documents = database.getCollection("Jobs").find(document1);
            //FindIterable<Document> documents = collection.find(query);

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext()) {
                while (cursor.hasNext()) {
                    document = cursor.next();
                    System.out.println(document.toJson());
                }
            } else
                document = new Document();
            /*while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }*/
        }

        if (op.equalsIgnoreCase("AppliedJobs")) {
            FindIterable<Document> documents = database.getCollection("Jobs").find();

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext()) {
                while (cursor.hasNext()) {
                    document = cursor.next();
                    System.out.println(document.toJson());
                }
            } else
                document = new Document();

        }
        mongoClient.close();
        return document;
    }
}

/*    public Document appliedJobs(JobSeekerBean JSBean, String op) {
        dbconn = new DbConnection();
        //MongoClient mongoClient = null;
        Document document=null;
        String connectionString = "mongodb://localhost:27017";
        mongoClient = MongoClients.create(connectionString);
        database = dbconn.getdbConnection(mongoClient);
        if (op.equalsIgnoreCase("AppliedJobs")) {
            Document document1 = new Document("Fname", JSBean.getFirstName());
            //Document regexFilter = new Document("SearchResult", new Document("$regex", JSBean.getKeyword()));
            FindIterable<Document> documents = database.getCollection("Jobs").find(document1);
            //FindIterable<Document> documents = collection.find(query);

            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext()){
                while (cursor.hasNext()) {
                    document = cursor.next();
                    System.out.println(document.toJson());
                }
            }
            else
                document=new Document();
            *//*while (cursor.hasNext()) {
                Document document = cursor.next();
                System.out.println(document.toJson());
            }*//*
        }

        mongoClient.close();
        return document;
    }*/

