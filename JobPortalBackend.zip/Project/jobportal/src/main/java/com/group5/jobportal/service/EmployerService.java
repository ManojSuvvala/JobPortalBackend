package com.group5.jobportal.service;

public interface EmployerService {

    public String Eregister(String  email, String password, String company);

    public String Elogin(String email, String password);
    public String EmpReq(String title, String description,String skills,String exp,String positions,String recruiterid,String pkg);

    public String editPost(String positions, String Pstatus);
}
