package com.group5.jobportal.ServImpl;

import com.group5.jobportal.Bean.JobSeekerBean;
import com.group5.jobportal.Bean.RecruiterBean;
import com.group5.jobportal.DbOperations.JobSeekerDbOperations;
import com.group5.jobportal.DbOperations.RecruiterDbOperations;
import com.group5.jobportal.service.RecruiterService;
import org.bson.Document;

public class RecruiterServImpl implements RecruiterService {

    RecruiterBean RBean=new RecruiterBean();
    //DbConnection dbconn=new DbConnection();
    RecruiterDbOperations rregi=new RecruiterDbOperations();
    @Override
    public String Rregister(String email, String password, String firstName, String lastName,String company)
    {
        String op="register";
        RBean.setEmail(email);
        RBean.setPassword(password);
        RBean.setEmail(email);
        RBean.setFirstName(firstName);
        RBean.setLastName(lastName);
        //String result=dbconn.getdbConnection(JSBean,op);
        String result=rregi.recruiter(RBean, op);
        return result;
    }


    @Override
    public String Rlogin(String email, String password)
    {
        String op="login";
        RBean.setEmail(email);
        RBean.setPassword(password);
        String result=rregi.recruiter(RBean,op);
        return result;
    }

    @Override
    public Document createdPosts(String id){
        String op="CreatedPosts";
        RBean.setRID(Rid);
        Document result=rregi.posts(RBean,op);
        return result;
    }

    /*public Document createdPosts(String description, String title, String skills, String exp, String positions, String recruiterid, String pkg) {
    }*/
}
