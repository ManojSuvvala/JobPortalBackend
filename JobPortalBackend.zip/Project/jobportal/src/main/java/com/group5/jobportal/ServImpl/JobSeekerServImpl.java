package com.group5.jobportal.ServImpl;

import com.group5.jobportal.Bean.JobSeekerBean;
import com.group5.jobportal.DbOperations.JobSeekerDbOperations;
import com.group5.jobportal.service.JobSeekerService;
import org.bson.Document;

public class JobSeekerServImpl implements JobSeekerService {
    JobSeekerBean JSBean=new JobSeekerBean();
    //DbConnection dbconn=new DbConnection();
    JobSeekerDbOperations jregi=new JobSeekerDbOperations();
    @Override
    public String Jregister(String username, String password, String email, String firstName, String lastName)
    {
        String op="register";
        JSBean.setUsername(username);
        JSBean.setPassword(password);
        JSBean.setEmail(email);
        JSBean.setFirstName(firstName);
        JSBean.setLastName(lastName);
        //String result=dbconn.getdbConnection(JSBean,op);
        String result=jregi.jobseeker(JSBean, op);
        return result;
    }


   @Override
    public String Jlogin(String username, String password)
    {
        String op="login";
        JSBean.setUsername(username);
        JSBean.setPassword(password);
        String result=jregi.jobseeker(JSBean,op);
        return result;
    }

    @Override
    public Document JSearch(String keyword) {
        String op="search";
        JSBean.setKeyword(keyword);
        Document result=jregi.jobs(JSBean,op);
        return result;
    }
    @Override
    public Document JAppliedJobs(String Jid){
        String op="AppliedJobs";
        JSBean.setKeyword(Jid);
        Document result=jregi.jobs(JSBean,op);
        return result;
    }
    @Override
    public Document JobsApps(){
        String op="JobsApps";
        Document result=jregi.jobs(JSBean,op);
        return result;
    }

}
