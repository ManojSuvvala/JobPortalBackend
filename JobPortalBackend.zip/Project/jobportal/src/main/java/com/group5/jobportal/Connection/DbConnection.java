package com.group5.jobportal.Connection;

import com.group5.jobportal.Bean.JobSeekerBean;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class DbConnection {

    //public MongoDatabase getdbConnection(JobSeekerBean JSBean, String op) {
    public MongoDatabase getdbConnection(MongoClient mongoClient) {
        String status="";

        MongoDatabase database = mongoClient.getDatabase("JobPortal");


        /*if (op.equalsIgnoreCase("register")) {
            Document document = new Document("Fname", JSBean.getFirstName()).append("Lname", JSBean.getLastName()).append("Email", JSBean.getEmail())
                    .append("Uname", JSBean.getUsername()).append("password", JSBean.getPassword());
            System.out.println(database.getCollection("JobSeeker").insertOne(document));
            mongoClient.close();
            status="success";
        }

        if (op.equalsIgnoreCase("login")) {
            Document document1 = new Document("Uname", JSBean.getUsername()).append("password", JSBean.getPassword());//.append("type", "Movie");
            System.out.println(database.getCollection("JobSeeker").find(document1));
            mongoClient.close();
            status="success";
        }*/
        return database;
    }

}
