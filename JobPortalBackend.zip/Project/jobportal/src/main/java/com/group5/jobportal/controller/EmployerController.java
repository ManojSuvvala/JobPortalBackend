package com.group5.jobportal.controller;

import com.group5.jobportal.ServImpl.EmployerServImpl;
import com.group5.jobportal.ServImpl.JobSeekerServImpl;
import com.group5.jobportal.service.JobSeekerService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class EmployerController {

    static EmployerServImpl Eservice=null;
    @RequestMapping("/ERegister")
    public static String JRegister(@RequestParam("email") String email,
                                   @RequestParam("password") String password,
                                   @RequestParam("company") String company) {
        Eservice=new EmployerServImpl();
        String result = Eservice.Eregister( email, password, company);
        if(result.equalsIgnoreCase("Success"))
            return "Registration Successful";
        else
            return "Unable to Register.Please try again after sometime";
    }

    @RequestMapping("/ELogin")
    public static String JLogin(@RequestParam("email") String email,
                                @RequestParam("password") String password) {
        Eservice=new EmployerServImpl();
        String result = Eservice.Elogin(email, password);
        if(result.equalsIgnoreCase("Success"))
            return "Registration Successful";
        else
            return "Unable to Login.Please create an account";
    }
    @RequestMapping("/EcreatePost")
    public static String createPost(@RequestParam("description") String description,
                                              @RequestParam("title") String title,
                                              @RequestParam("skills") String skills,
                                              @RequestParam("exp") String exp,
                                              @RequestParam("positions") String positions,
                                              @RequestParam("recruiterid") String recruiterid,
                                              @RequestParam("package") String pkg) {
        Eservice=new EmployerServImpl();
        String result = Eservice.EmpReq(title, description, skills, exp,positions, recruiterid, pkg);
        if(result.equalsIgnoreCase("Success"))
            return "Created post Successfully";
        else
            return "Unable to create post.Please try again after sometime";
    }
    @RequestMapping("/EEditPost")
    public static String EditPost(@RequestParam("positions") String positions,
                                    @RequestParam("pstatus") String Pstatus) {
        Eservice=new EmployerServImpl();
        String result = Eservice.editPost(positions, Pstatus);
        if(result.equalsIgnoreCase("Success"))
            return "Information updated successfully";
        else
            return "Unable update the provided information.Please try again after sometime";
    }
}
