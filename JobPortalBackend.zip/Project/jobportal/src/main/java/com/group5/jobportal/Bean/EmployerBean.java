package com.group5.jobportal.Bean;

public class EmployerBean {
    String EmployerId;
    String password;
    String email;
    String company;
    String postStatus;
    String IsExpired;


    String description;
    String skills;
    String exp;
    String positions;
    String recruiterid;
    String pkg;
    String title;

    public String getEmployerId() {
        return EmployerId;
    }

    public void setEmployerId(String employerId) {
        EmployerId = employerId;
    }

    public String getIsExpired() {
        return IsExpired;
    }

    public void setIsExpired(String IsExpired) {
        IsExpired = IsExpired;
    }

    public String getPostStatus() {
        return postStatus;
    }

    public void setPostStatus(String postStatus) {
        this.postStatus = postStatus;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }



    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSkills() {
        return skills;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public String getPositions() {
        return positions;
    }

    public void setPositions(String positions) {
        this.positions = positions;
    }

    public String getRecruiterid() {
        return recruiterid;
    }

    public void setRecruiterid(String recruiterid) {
        this.recruiterid = recruiterid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPkg() {
        return pkg;
    }

    public void setPkg(String pkg) {
        this.pkg = pkg;
    }

}
