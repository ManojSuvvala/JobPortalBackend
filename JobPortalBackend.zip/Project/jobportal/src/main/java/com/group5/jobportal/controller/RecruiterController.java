package com.group5.jobportal.controller;

import com.group5.jobportal.ServImpl.EmployerServImpl;
import com.group5.jobportal.ServImpl.JobSeekerServImpl;
import com.group5.jobportal.ServImpl.RecruiterServImpl;
import org.bson.Document;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RecruiterController {
    static RecruiterServImpl Rservice=null;
    @RequestMapping("/RRegister")
    public static String JRegister(@RequestParam("email") String email,
                                   @RequestParam("password") String password,
                                   @RequestParam("firstName") String firstName,
                                   @RequestParam("lastName") String lastName,
                                   @RequestParam("company") String company) {
        Rservice=new RecruiterServImpl();
        String result = Rservice.Rregister(password, email, firstName, lastName,company);
        if(result.equalsIgnoreCase("Success"))
            return "Registration Successful";
        else
            return "Unable to Register.Please try again after sometime";
    }

    @RequestMapping("/RLogin")
    public static String JLogin(@RequestParam("email") String email,
                                @RequestParam("password") String password) {
        Rservice=new RecruiterServImpl();
        String result = Rservice.Rlogin(email, password);
        if(result.equalsIgnoreCase("Success"))
            return "Registration Successful";
        else
            return "Unable to Login.Please create an account";
    }
    @RequestMapping("/RPosts")
    public static String postsCreated(@RequestParam("RID") String RId) {
        Rservice=new RecruiterServImpl();
        Document result = Rservice.createdPosts(RId);
        if(!result.isEmpty()&&result!=null)
            return result.toJson();
        else
            return "Unable to get the Posts. PLease try again later.";
    }

   /* @RequestMapping("/RCreatePost")
    public static String CreatePost(@RequestParam("description") String description,
                                    @RequestParam("title") String title,
                                    @RequestParam("skills") String skills,
                                    @RequestParam("exp") String exp,
                                    @RequestParam("positions") String positions,
                                    @RequestParam("recruiterid") String recruiterid,
                                    @RequestParam("package") String pkg) {
        Rservice=new RecruiterServImpl();
        Document result = Rservice.createdPosts(description,title,skills,exp,positions,recruiterid,pkg);
        if(!result.isEmpty())
            return result.toJson();
        else
            return "Unable to get the Posts. PLease try again later.";
    }*/
}
