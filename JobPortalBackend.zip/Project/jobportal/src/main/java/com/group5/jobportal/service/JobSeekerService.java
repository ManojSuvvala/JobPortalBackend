package com.group5.jobportal.service;

import org.bson.Document;
import org.springframework.web.bind.annotation.RequestParam;

public interface JobSeekerService {
    public String Jregister(String username,String password,String email,String firstName,String lastName);
    public String Jlogin(String username,String password);
    public Document JSearch(String keyword);
    public Document JAppliedJobs(String Jid);
    public Document JobsApps();

}
