package com.group5.jobportal.service;

import org.bson.Document;

public interface RecruiterService {
    public String Rregister(String email,String password,String firstName,String lastName,String company);
    public String Rlogin(String email,String password);
    public Document createdPosts(String Jid);
}
