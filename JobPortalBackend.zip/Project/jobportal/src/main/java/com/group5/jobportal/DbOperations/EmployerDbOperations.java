package com.group5.jobportal.DbOperations;

import com.group5.jobportal.Bean.EmployerBean;
import com.group5.jobportal.Bean.JobSeekerBean;
import com.group5.jobportal.Connection.DbConnection;
import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.InsertOneResult;
import com.mongodb.client.result.UpdateResult;
import org.bson.Document;

import java.util.Arrays;
import java.util.Date;

public class EmployerDbOperations {
    DbConnection dbconn = null;
    MongoClient mongoClient = null;
    MongoDatabase database = null;
    public String employer(EmployerBean EBean, String op) {
        dbconn = new DbConnection();
        String connectionString = "mongodb://localhost:27017";
        mongoClient = MongoClients.create(connectionString);
        database = dbconn.getdbConnection(mongoClient);
        String status = "";

        if (op.equalsIgnoreCase("register")) {
            Document document = new Document("Email", EBean.getEmail()).append("Password", EBean.getPassword()).append("Employer", EBean.getCompany());
            MongoCollection<Document> collection = database.getCollection("Employer");
            InsertOneResult result = collection.insertOne(document);
            if (!result.getInsertedId().isNull())
                status = "success";
            else
                status = "fail";
            System.out.println("Inserted ID: " + result.getInsertedId());
        } else if (op.equalsIgnoreCase("login")) {
            Document document1 = new Document("Email", EBean.getEmail()).append("password", EBean.getPassword());
            FindIterable<Document> documents = database.getCollection("Employer").find(document1);
            MongoCursor<Document> cursor = documents.iterator();
            if (cursor.hasNext())
                status = "success";
            else
                status = "fail";
        } else if (op.equalsIgnoreCase("empReq")) {
            Document document1 = new Document("Description", EBean.getDescription()).append("Experience", EBean.getExp())
                    .append("Title", EBean.getTitle()).append("Employer_Id", EBean.getEmployerId())
                    .append("Package", EBean.getPkg()).append("Position", EBean.getPositions())
                    .append("Skills", EBean.getSkills()).append("Recruiter_ID", EBean.getRecruiterid())
                    .append("Date",new Date()).append("IsExpired",EBean.getIsExpired());
            MongoCollection<Document> collection = database.getCollection("JobPosts");
            InsertOneResult result = collection.insertOne(document1);
            if (!result.getInsertedId().isNull())
                status = "success";
            else
                status = "fail";
        }else if (op.equalsIgnoreCase("editpost")) {
            /*Document document1 = new Document("key", "value");
            Document update = new Document("$set", new Document("newField", "updatedValue"));
            MongoCollection<Document> collection = database.getCollection("EmployerPosts");
            collection.updateOne(document1, update);*/
            MongoCollection<Document> collection = database.getCollection("JobPosts");
            Document filter = new Document("$and",
                    Arrays.asList(
                            Filters.eq("_id", "6524e5afa06ba79018a5bf5a")//, given hardcoded id need to work on it
                            //Filters.eq("field2", "value2")
                    )
            );

            Document update = new Document("$set",
                    new Document("Positions",EBean.getPositions()).append("IsExpired",EBean.getIsExpired())
            );

            UpdateResult result = collection.updateMany(filter, update);

            if (result.getModifiedCount()>0)
                status = "success"+result.getModifiedCount();
            else
                status = "fail";
        }
        mongoClient.close();
        return status;
    }
}
