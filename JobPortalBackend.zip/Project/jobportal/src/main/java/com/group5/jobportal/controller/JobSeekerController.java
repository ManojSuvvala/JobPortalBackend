package com.group5.jobportal.controller;

import com.group5.jobportal.ServImpl.JobSeekerServImpl;
import com.group5.jobportal.service.JobSeekerService;
import org.bson.Document;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping("/JobSeeker")
public class JobSeekerController {
    //@RequestMapping("/JobSeeker")
    //public static String getmessage() {
        //return "welcome to Springboot";
    //}
    static JobSeekerService JSservice=null;
    @RequestMapping("/JRegister")
    public static String JRegister(@RequestParam("username") String username,
                                   @RequestParam("password") String password,
                                   @RequestParam("email") String email,
                                   @RequestParam("firstName") String firstName,
                                   @RequestParam("lastName") String lastName) {
        JSservice=new JobSeekerServImpl();
        String result = JSservice.Jregister(username, password, email, firstName, lastName);
        if(result.equalsIgnoreCase("Success"))
            return "Registration Successful";
        else
            return "Unable to Register.Please try again after sometime";
    }

    @RequestMapping("/JLogin")
    public static String JLogin(@RequestParam("username") String username,
                                    @RequestParam("password") String password) {
        JSservice=new JobSeekerServImpl();
        String result = JSservice.Jlogin(username, password);
        if(result.equalsIgnoreCase("Success"))
            return "Registration Successful";
        else
            return "Unable to Login.Please create an account";
    }

    @RequestMapping("/JSearch")
    public static String JSearch(@RequestParam("keyword") String keyword) {
        JSservice=new JobSeekerServImpl();
        System.out.println("inside JSearch");
        Document result = JSservice.JSearch(keyword);
        if(!result.isEmpty())
            return result.toJson();
        else
            return "No records found for the search criteria";
    }

    @RequestMapping("/JJobApplication")
    public static String JJobApplication() {
        JSservice=new JobSeekerServImpl();
        Document result = JSservice.JobsApps();
        if(!result.isEmpty())
            return result.toJson();
        else
            return "welcome to Springboot JJobApplication";
    }

    @RequestMapping("/JAppliedJobs")
    public static String JAppliedJobs(@RequestParam("JId") String JId) {
        JSservice=new JobSeekerServImpl();
        Document result = JSservice.JAppliedJobs(JId);
        if(!result.isEmpty())
            return result.toJson();
        else
            return "welcome to Springboot JAppliedJobs";
    }
}
